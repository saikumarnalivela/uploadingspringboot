package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.FileClass;

public interface FileRepository extends JpaRepository<FileClass, String>{

}
